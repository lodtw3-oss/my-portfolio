Simple proxy server to avoid CORS when fetching finance data.

Setup:

1. Create a `.env` file in `server/` with your Finnhub API key (optional):

FINNHUB_KEY=your_finnhub_key_here

2. Install and run:

```bash
cd server
npm install
npm start
```

The server listens on port 4000 by default. Endpoints:

- GET /api/quote?symbol=XXX&market=TW  => returns { price, change, raw }
- GET /api/quote?symbol=XXX&market=US  => tries Finnhub (if key set) then Yahoo

In development, point the frontend `fetchFinanceData` to `http://localhost:4000/api/quote` (this repo already updated the client to call `/api/quote`).
