﻿import express from "express";
import fs from "fs";
import path from "path";

const app = express();
const PORT = 4000;

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  next();
});

app.use(express.json({ limit: "10mb" }));

const formatDateInTimeZone = (timestampMs, timeZone) =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(timestampMs));

const isValidYmd = (value) => /^\d{4}-\d{2}-\d{2}$/.test(value || "");

const parseSymbolAndMarket = (req) => {
  const primary = {
    symbol: (req.query.symbol || "").toString().trim().toUpperCase(),
    market: ((req.query.market || "US").toString().trim().toUpperCase() || "US"),
  };

  if (primary.symbol) return primary;

  try {
    const keys = Object.keys(req.query || {});
    for (const key of keys) {
      if (typeof key !== "string") continue;
      if (!key.includes("symbol=") && !key.includes("market=")) continue;
      const usp = new URLSearchParams(key);
      const symbol = (usp.get("symbol") || "").trim().toUpperCase();
      const market = (usp.get("market") || "US").trim().toUpperCase();
      if (symbol) return { symbol, market: market || "US" };
    }
  } catch {
    // ignore malformed fallback query shapes
  }

  return { symbol: "", market: "US" };
};

const getYahooSymbols = (symbol, market) => {
  if (market === "TW") {
    if (/\.(TW|TWO)$/i.test(symbol)) {
      return [symbol.toUpperCase()];
    }

    return [`${symbol}.TW`, `${symbol}.TWO`];
  }

  if (market === "US") {
    return [symbol.replace(/\.US$/i, "").replace(/-US$/i, "").replace(/_US$/i, "")];
  }

  return [symbol];
};

app.get("/api/quote", async (req, res) => {
  const { symbol, market } = parseSymbolAndMarket(req);
  const targetDate = (req.query.date || "").toString().trim();

  if (!symbol) {
    return res.status(400).json({ error: "symbol required" });
  }

  if (targetDate && !isValidYmd(targetDate)) {
    return res.status(400).json({ error: "date must be YYYY-MM-DD" });
  }

  const yahooSymbols = getYahooSymbols(symbol, market);

  try {
    if (targetDate) {
      const marketTimeZone = market === "TW" ? "Asia/Taipei" : "America/New_York";
      let lastChartError = null;

      for (const yahooSymbol of yahooSymbols) {
        const rangeStart = new Date(`${targetDate}T00:00:00Z`);
        rangeStart.setUTCDate(rangeStart.getUTCDate() - 14);
        const rangeEnd = new Date(`${targetDate}T23:59:59Z`);
        rangeEnd.setUTCDate(rangeEnd.getUTCDate() + 2);

        const chartUrl =
          `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(yahooSymbol)}` +
          `?interval=1d&period1=${Math.floor(rangeStart.getTime() / 1000)}` +
          `&period2=${Math.floor(rangeEnd.getTime() / 1000)}` +
          `&includePrePost=false&events=div%2Csplits&_=${Date.now()}`;
        const chartRes = await fetch(chartUrl);
        const chartData = await chartRes.json();
        const result = chartData.chart?.result?.[0];

        if (!result) {
          lastChartError = chartData;
          continue;
        }

        const timestamps = result.timestamp || [];
        const closes = result.indicators?.quote?.[0]?.close || [];
        const points = timestamps
          .map((ts, index) => {
            const close = closes[index];
            if (close == null || close === 0) return null;
            return {
              timestamp: ts,
              date: formatDateInTimeZone(ts * 1000, marketTimeZone),
              close,
            };
          })
          .filter(Boolean)
          .sort((a, b) => a.timestamp - b.timestamp);

        const selectedIndex = points.findLastIndex((point) => point.date === targetDate);

        if (selectedIndex === -1) {
          lastChartError = chartData;
          continue;
        }

        const selected = points[selectedIndex];
        const previous = selectedIndex > 0 ? points[selectedIndex - 1] : null;
        const change =
          previous && previous.close
            ? ((selected.close - previous.close) / previous.close) * 100
            : 0;

        return res.json({
          price: selected.close,
          change,
          asOfDate: selected.date,
          previousCloseDate: previous?.date ?? null,
          raw: chartData,
        });
      }

      return res.status(404).json({ error: "No historical close found for symbol", raw: lastChartError });
    }

    let lastQuotePayload = null;

    for (const yahooSymbol of yahooSymbols) {
      const quoteUrl = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${encodeURIComponent(yahooSymbol)}&_=${Date.now()}`;
      const quoteRes = await fetch(quoteUrl);
      const quoteData = await quoteRes.json();
      const quote = quoteData.quoteResponse?.result?.[0];

      if (quote && quote.regularMarketPrice != null) {
        const price =
          [quote.postMarketPrice, quote.preMarketPrice, quote.regularMarketPrice, quote.previousClose].find(
            (value) => value != null && value !== 0
          ) ?? null;
        const change =
          quote.regularMarketChangePercent != null
            ? quote.regularMarketChangePercent
            : quote.postMarketChangePercent ?? quote.preMarketChangePercent ?? 0;

        return res.json({
          price,
          change,
          raw: quoteData,
        });
      }

      const intradayUrl = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(yahooSymbol)}?interval=1m&range=1d&_=${Date.now()}`;
      const intradayRes = await fetch(intradayUrl);
      const intradayData = await intradayRes.json();
      const result = intradayData.chart?.result?.[0];

      if (!result) {
        lastQuotePayload = intradayData;
        continue;
      }

      const meta = result.meta;
      const quoteClose = result.indicators?.quote?.[0]?.close || [];
      const lastQuotePrice = [...quoteClose].reverse().find((value) => value != null && value !== 0) ?? null;
      const price =
        lastQuotePrice ??
        [meta.postMarketPrice, meta.preMarketPrice, meta.regularMarketPrice, meta.previousClose].find(
          (value) => value != null && value !== 0
        ) ??
        null;
      const previousClose = meta.chartPreviousClose ?? meta.previousClose ?? price;
      const change =
        previousClose != null && previousClose !== 0
          ? ((price - previousClose) / previousClose) * 100
          : 0;

      return res.json({
        price,
        change,
        raw: intradayData,
      });
    }

    return res.status(404).json({ error: "No data for symbol", raw: lastQuotePayload });
  } catch (error) {
    console.error("quote error", error);
    return res.status(500).json({ error: "fetch failed" });
  }
});

app.get("/api/test-csv", (req, res) => {
  try {
    const currentFilePath = new URL(import.meta.url).pathname;
    const serverDir = path.dirname(currentFilePath);
    const projectRoot = path.resolve(serverDir, "..");
    const recordDir = path.join(projectRoot, "record");

    if (!fs.existsSync(recordDir)) {
      fs.mkdirSync(recordDir, { recursive: true });
    }

    const testContent = "date,timestamp,totalValue,test\n2024-01-01,2024-01-01T00:00:00Z,1000,true";
    const testFilename = `test_${Date.now()}.csv`;
    const filePath = path.join(recordDir, testFilename);

    fs.writeFileSync(filePath, testContent, "utf8");

    res.json({
      success: true,
      message: "Test CSV created",
      path: filePath,
      recordDir,
      files: fs.readdirSync(recordDir),
    });
  } catch (error) {
    console.error("test csv error", error);
    res.status(500).json({ error: "test failed", details: error.message });
  }
});

app.post("/api/save-csv", (req, res) => {
  const { filename, content } = req.body;

  if (!filename || !content) {
    return res.status(400).json({ error: "filename and content are required" });
  }

  try {
    const currentFilePath = new URL(import.meta.url).pathname;
    const serverDir = path.dirname(currentFilePath);
    const projectRoot = path.resolve(serverDir, "..");
    const recordDir = path.join(projectRoot, "record");

    if (!fs.existsSync(recordDir)) {
      fs.mkdirSync(recordDir, { recursive: true });
    }

    const filePath = path.join(recordDir, filename);
    fs.writeFileSync(filePath, content, "utf8");

    return res.json({ success: true, path: filePath });
  } catch (error) {
    console.error("save csv error", error);
    return res.status(500).json({ error: "save failed", details: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Quote proxy running at http://localhost:${PORT}`);
  console.log(
    `Record directory: ${path.join(path.resolve(path.dirname(new URL(import.meta.url).pathname), ".."), "record")}`
  );
});
